
/* NÃO MODIFIQUE ESTE ARQUIVO! */

#include <iostream>
#include <ctime>
#include <list>
#include <cstdlib>

using namespace std;

int* vetor_aleatorio(int semente, int tamanho)
{
   srand(semente);
   int *v = new int[tamanho];
   for (int i = 0; i < tamanho; i++)
      if (rand() < 0.5 * RAND_MAX) v[i] = tamanho / 2;
      else v[i] = rand() % tamanho;
   return v;
}

void avalia(string nome, int (*f)(int*,int), int semente, int v[], int n, double tempo_esperado)
{
   clock_t begin = clock();
   cout << nome << (*f)(v,n) << " ";
   clock_t end = clock();
   double tempo = double(end - begin) / CLOCKS_PER_SEC;
   if ((tempo >= tempo_esperado/3.16) && (tempo <= 3.16*tempo_esperado))
      cout << "Tempo: " << tempo_esperado << "s" << endl;
   else cout << "Tempo fora da faixa prevista: " << tempo << "s" << endl;
}

int majoritario_forca_bruta(int v[], int n);
int majoritario_ordenando(int v[], int n);
int majoritario_divisao_conquista(int v[], int n);
int majoritario_iterativo(int A[], int n);

int main()
{
   int semente, n; double tempo_fb, tempo_ord, tempo_dc, tempo_iter;
   cin >> semente; cin >> n; cin >> tempo_fb; cin >> tempo_ord; cin >> tempo_dc; cin >> tempo_iter;
   int *v = vetor_aleatorio(semente, n);
   
   avalia("Forca bruta: ", &majoritario_forca_bruta, semente, v, n, tempo_fb);
   avalia("Ordenado: ", &majoritario_ordenando, semente, v, n, tempo_ord);
   avalia("Divisao e conquista: ", &majoritario_divisao_conquista, semente, v, n, tempo_dc);
   avalia("Recursao de cauda (iterativo): ", &majoritario_iterativo, semente, v, n, tempo_iter);
}
