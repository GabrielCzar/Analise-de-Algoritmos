
// Encontrar elemento majoritário.
// Recebe um vetor A contendo n elementos não negativos.
// Retorna o valor que aparece em mais da metade dos elementos de A, ou -1 se 
// não existe este valor. Obs.: Não assume que o vetor A está ordenado.

int majoritario_forca_bruta(int A[], int n);
int majoritario_ordenando(int A[], int n);
int majoritario_divisao_conquista(int A[], int n);
int majoritario_iterativo(int A[], int n);
